const attendees = [
  'Bethany',
  'Adrianna',
  'Soren',
  'Guy',
  'Alicia',
  'Thomas',
  'Gen',
  'Mikelle',
  'Elijah',
  'Wesley',
  'Veronica',
  'Lesslie'
]

const contacted = [
  'Gen',
  'Mikelle',
  'Soren',
  'Lesslie'
]

const toContact = _.difference(attendees, contacted)

const attendeesEl = document.querySelector('#attendees')
attendees.forEach(attendee => {
  attendeesEl.innerHTML = attendeesEl.innerHTML + '<br />' + attendee
})

const contactedEl = document.querySelector('#contacted')
contacted.forEach(attendee => {
  contactedEl.innerHTML = contactedEl.innerHTML + '<br />' + attendee
})

const toContactEl = document.querySelector('#to-contact')
toContact.forEach(attendee => {
  toContactEl.innerHTML = toContactEl.innerHTML + '<br />' + attendee
})

const marie = ['rose', 'tulip', 'begonia']
const gen = ['rose', 'poppy', 'orchid']
const alicia = ['daisy', 'dahlia', 'lavender']
const mikelle = ['daffodil', 'tulip', 'peony']
const larry = ['pansy', 'rose', 'lilac']
const martin = ['crocus', 'sunflower', 'poppy']
const felicia = ['honeysuckle', 'orchid', 'rose']
const chris = ['begonia', 'rose', 'tulip']
const edgar = ['chrysanthemum', 'iris', 'lily']
const susan = ['tulip', 'rose', 'peony']
const veronica = ['cyclamen', 'poppy', 'sunflower']

const all = marie.concat(gen, alicia, mikelle, larry, martin, felicia, chris, edgar, susan, veronica)

const uniques = _.uniq(all)
console.log(uniques)

const kids = [
  { name: 'Alice', age: 9},
  { name: 'Bob', age: 12},
  { name: 'Connie', age: 7},
  { name: 'D\'Angelo', age: 12},
  { name: 'Ellen', age: 14},
  { name: 'Felicia', age: 10},
  { name: 'Georgie', age: 13},
  { name: 'Helen', age: 15},
  { name: 'Iona', age: 8},
  { name: 'Jackie', age: 11},
  { name: 'Kyle', age: 15},
]

const minimumAge = 8
const maximumAge = 13

kids.forEach(kid => {
  let inRange = _.inRange(kid.age, minimumAge, maximumAge);
  if (inRange) { 
    console.log('Welcome,', kid.name) 
  } else {
    console.log('Sorry,', kid.name)
  }
})

const string1 = 'FeLiCiA'
const string2 = 'FELICIA'
const string3 = 'felicia'
console.log(_.capitalize(string1))
console.log(_.capitalize(string2))
console.log(_.capitalize(string3))

const products = [
  'MBT8975',
  'RDS2614',
  'IBM6472',
  'IBM2398',
  'DEV9121',
  'IBM1887',
  'TRS6311'
]
products.forEach( sku => {
  if( _.startsWith(sku, 'IBM')) {
    console.log(sku);
  }
})