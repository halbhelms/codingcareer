let getTemplates = (path) => {
  fetch(`../html/${path}.html`)
  .then( data => data.text())
  .then( data => document.getElementById(`main`).innerHTML = data
  )
  .catch( e => {console.log(e)})
}

let displayWelcome = (event) => {
  getTemplates('welcome')
}
document.querySelector('#welcome').addEventListener('click', displayWelcome)