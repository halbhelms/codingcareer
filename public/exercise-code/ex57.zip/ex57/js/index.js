// create a "tee" object to store options
const tee = {
  text: null,
  font: null,
  color: 'black'
}

// create a "setText" function to be used with event listener for #text
const setText = event => {
  tee.text = event.target.value
  paintTee()
}
document.querySelector('#text').addEventListener('blur', setText)

// create a "setFont" function to be used with event listener for typeface
const setFont = event => {
  tee.font = event.target.value
  paintTee()
}
document.querySelector('#typeface').addEventListener('change', setFont)

// create a "setColor" function to be used with event listener for color
const setColor = event => {
  tee.color = event.target.value
  paintTee()
}
document.querySelector('#color').addEventListener('change', setColor)

// create a "paintTee" function that applies all of tee's values to the tee shirt
const paintTee = () => {
  const sampleText = document.querySelector('#sampleText')
  sampleText.innerHTML = tee.text
  sampleText.style.cssText = `color: ${tee.color};`
  sampleText.classList = null
  sampleText.classList.add(tee.font)
}
