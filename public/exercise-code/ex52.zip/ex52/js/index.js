
// fetch info on a particular movie from omdbapi
let makeRequest = async (movie) => {
  try {
    movie = movie.replace(' ', '+')
    let result = await fetch(`http://www.omdbapi.com/?apikey=f7d1d384&t=${movie}`)
    return result.json()
  } catch(e) {
    console.log(e)
  }
}

// get information on each movie and place the info in the appropriate HTML element
let movieInfo = async event => {
  let data = await makeRequest(event.target.dataset.title)
  document.querySelector('#title').innerHTML = data.Title
  document.querySelector('#actors').innerHTML = data.Actors
  document.querySelector('#director').innerHTML = data.Director
  document.querySelector('#year').innerHTML = data.Year
  document.querySelector('#rating').innerHTML = data.imdbRating
  document.querySelector('#plot').innerHTML = data.Plot
  document.querySelector('img').src = data.Poster
}

// add event listener to each movie
const movies = document.querySelectorAll('.genre > div')
const moviesArray = Array.prototype.slice.call(movies)
movies.forEach( movie => {
  movie.addEventListener('click', movieInfo)}
)