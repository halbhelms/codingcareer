// create an unshuffled deck of cards
let suits = ['C','D','H','S']
let pips = [2,3,4,5,6,7,8,9,10,11,12,13,14]
let unshuffledDeck = () => {
  let arr = []
  suits.forEach( suit => {
    pips.forEach( pip => {
      arr.push(pip + suit)
    })
  })
  return arr
}

// write a "shuffle" function
let shuffle = array => {
  array.sort(() => Math.random() - 0.5);
  return array
}

// create four shuffled decks
let shuffledDeck1 = shuffle(unshuffledDeck())
let shuffledDeck2 = shuffle(unshuffledDeck())
let shuffledDeck3 = shuffle(unshuffledDeck())
let shuffledDeck4 = shuffle(unshuffledDeck())

// combine the four decks
let bigDeck = shuffledDeck1.concat(shuffledDeck2).concat(shuffledDeck3).concat(shuffledDeck4)

// shuffle the bigDeck
let deck = shuffle(bigDeck)

// write a "dealCard" function
let dealCard = deck => {
  let dealtCard = deck.shift()
  return dealtCard
}

// create object to store cards
let currentHand = {
  player: [],
  dealer: []
}

// after initialDeal, does either one have a Blackjack?
let isBlackjack = handValue => {
  return handValue === 21
}

// create a function to evaluate the value of a hand
let valueHand = hand => {
  let handValue = 0
  hand.forEach(card => {
    let regex = /[0-9]*/
    let cardValue = parseInt(regex.exec(card))
    if (cardValue > 10 && cardValue < 14) { cardValue = 10 }
    if (cardValue === 14) { cardValue = 11 }
    handValue += cardValue
  })
  return handValue
}

// create a variable, "inHand", as a boolean defaulting to false
let inHand = false;

// create an initialDeal function that will give each player 2 cards, but one of the dealer's cards should be displayed face-down
let initialDeal = () => {
  inHand = true
  currentHand.player = []
  currentHand.dealer = []

  currentHand.player.push(dealCard(bigDeck))
  currentHand.dealer.push(dealCard(bigDeck))
  currentHand.player.push(dealCard(bigDeck))
  currentHand.dealer.push(dealCard(bigDeck))

  // let playerHand = document.querySelector('#player')
  let dealerHand = document.querySelector('#dealer')

  dealerHand.innerHTML = ''
    
  cardImg = document.createElement('img')
  imgSrc = document.createAttribute('src')
  imgSrc.value = `../images/cards/blue_back.png`
  cardImg.setAttributeNode(imgSrc)
  dealerHand.appendChild(cardImg)

  cardImg = document.createElement('img')
  imgSrc = document.createAttribute('src')
  imgSrc.value = `../images/cards/${currentHand.dealer[1]}.png`
  cardImg.setAttributeNode(imgSrc)
  dealerHand.appendChild(cardImg)

  displayCards('player')

  let winner = document.querySelector('#winner')
  let dealerWins = isBlackjack(valueHand(currentHand.dealer))
  let playerWins = isBlackjack(valueHand(currentHand.player))

  if (dealerWins) {
    displayCards('dealer')
    winner.innerHTML = 'Dealer wins with Blackjack'
    inHand = false
  }
  if (playerWins) {
    winner.innerHTML = 'Player wins with Blackjack'
    inHand = false
  }
  if (playerWins && dealerWins) {
    winner.innerHTML = 'Tie with Blackjacks'
    inHand = false
  }
}

let isBusted = handValue => {
  return handValue > 21
}

let displayCards = who => {
  let display = document.querySelector(`#${who}`)
  display.innerHTML = ''
  currentHand[who].forEach( card => {
    let cardImg = document.createElement('img')
    let imgSrc = document.createAttribute('src')
    imgSrc.value = `../images/cards/${card}.png`
    cardImg.setAttributeNode(imgSrc)
    display.appendChild(cardImg)
  })
}

let deal = () => {
  if (inHand) {
    let nextCard = dealCard(deck)
    currentHand.player.push(nextCard)
    displayCards('player')
    if (isBusted(valueHand(currentHand.player))) {
      document.querySelector('#winner').innerHTML = 'Player busts'
      inHand = false
    }
  } else {
    document.querySelector('#winner').innerHTML = ''
    initialDeal()
  }
}

// create function, "evaluateWinner", that returns who has higher hand total (as long as it's less than 22)
let evaluateWinner = () => {
  let playerHandValue = valueHand(currentHand.player)
  let dealerHandValue = valueHand(currentHand.dealer)
  if (isBusted(playerHandValue)) { return 'Dealer' }
  if (isBusted(dealerHandValue)) { return 'Player' }
  if (playerHandValue > dealerHandValue) { return 'Player' }
  if (dealerHandValue > playerHandValue) { return 'Dealer' }
}

let stay = () => {
  // setup
  let winner = document.querySelector('#winner')
  let playerHandValue = valueHand(currentHand.player)
  let dealerHandValue = valueHand(currentHand.dealer)
  // if we're not in a hand, return
  if (!inHand) { return}
  // if the player busted, return
  if (isBusted(playerHandValue)) { return }
  // if the dealer busted, notify, set inHand to false, and exit
  if (isBusted(dealerHandValue)) {
    winner.innerHTML = 'Player wins'
    displayCards('dealer')
    inHand = false
    return
  } 
  // Is the dealer's hand good at this point (>16 and <22)?
  // If so, we're done and need to evaluate a winner
  if (dealerHandValue > 16 && dealerHandValue < 22) {
    let victor = evaluateWinner()
    document.querySelector('#winner').innerHTML = `${victor} wins`
    displayCards('dealer')
    inHand = false
    return
  }

  // If the dealer hand wasn't between 16 and 22, deal another card
  currentHand.dealer.push(dealCard(deck))
  // ...and check if that busted the dealer)
  dealerHandValue = valueHand(currentHand.dealer)
  if (isBusted(dealerHandValue)) {
    inHand = false
    displayCards('dealer')
    winner.innerHTML = 'Player wins'
    return
  }
  // Dealer didn't bust? Then see if dealer hand value > 16. If not, call "stay()". 
  if (dealerHandValue < 16) { stay() }
  
  // If so, we're done and need to evaluate a winner
  if (dealerHandValue > 16 && dealerHandValue < 22) {
    let victor = evaluateWinner()
    document.querySelector('#winner').innerHTML = `${victor} wins`
    displayCards('dealer')
    inHand = false
    return
  }
}


document.querySelector('#deal').addEventListener('click', deal)
document.querySelector('#stay').addEventListener('click', stay)

