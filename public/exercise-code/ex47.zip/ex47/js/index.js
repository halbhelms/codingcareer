// create an unshuffled deck of cards
let suits = ['C','D','H','S']
let pips = [2,3,4,5,6,7,8,9,10,11,12,13,14]
let unshuffledDeck = () => {
  let arr = []
  suits.forEach( suit => {
    pips.forEach( pip => {
      arr.push(pip + suit)
    })
  })
  return arr
}

// write a "shuffle" function
let shuffle = array => {
  array.sort(() => Math.random() - 0.5);
  return array
}

// create a shuffled deck
let shuffledDeck = shuffle(unshuffledDeck())

// write a "dealCard" function
let dealCard = deck => {
  let dealtCard = shuffledDeck.shift()
  return dealtCard
}

// create a "wins" object with playerA and playerB as keys
let wins = {
  playerA: 0,
  playerB: 0
}

// deal to playerA and playerB
let currentDeal = {
  playerA: null,
  playerB: null
}

let deal = () => {
  let playerAcards = document.getElementById('playerA')
  playerAcards.innerHTML = '<h2>Player A</h2>'
  currentDeal.playerA = dealCard(shuffledDeck)
  let img = document.createElement('img')
  let imgSrc = document.createAttribute('src')
  imgSrc = `../images/cards/${currentDeal.playerA}.png`
  img.setAttribute('src', imgSrc)
  playerAcards.appendChild(img)

  let playerBcards = document.getElementById('playerB')
  playerBcards.innerHTML = '<h2>Player B</h2>'
  currentDeal.playerB = dealCard(shuffledDeck)
  img = document.createElement('img')
  imgSrc = document.createAttribute('src')
  imgSrc = `../images/cards/${currentDeal.playerB}.png`
  img.setAttribute('src', imgSrc)
  playerBcards.appendChild(img)
}


// evaluate winner
let evaluateWinner = currentDeal => {
  let regex = /[0-9]*/
  let playerA = parseInt(regex.exec(currentDeal.playerA)[0])
  let playerB = parseInt(regex.exec(currentDeal.playerB)[0])
  let winner = "TIE"
  if (playerA > playerB) { 
    winner = 'Player A'
    wins.playerA = wins.playerA + 1
  }
  if (playerB > playerA) { 
    winner = 'Player B'
    wins.playerB = wins.playerB + 1
  }

  document.getElementById('winner').innerHTML = winner + ' wins!'
}

// create "showScore" function that displays the current score
let showScore = wins => {
  let message = `Player A: ${wins.playerA} <br />Player B: ${wins.playerB}`
  document.getElementById('score').innerHTML = message
}

// create a "newDeal" function to be passed as an event listener to button
let newDeal = () => {
  if (shuffledDeck.length > 1) {
    deal()
    evaluateWinner(currentDeal)
    showScore(wins)
  }
}

const henryVIII = {
  yearBorn: 1491,
  yearDied: 1547,
  yearsInPower: '1509 - 1547',
  marriages: [
    {
      spouse: 'Catherine of Aragorn',
      children: ['Henry', 'Mary']
    },
    {
      spouse: 'Anne Boleyn',
      children: ['Elizabeth']
    },
    {
      spouse: 'Jane Seymour',
      children: ['Edward']
    },
    {
      spouse: 'Anne of Cleves',
      children: []
    },
    {
      spouse: 'Catherine Howard',
      children: []
    },
    {
      spouse: 'Catherine Parr',
      children: []
    }
  ]
}
document.getElementById('dump').innerHTML = dump(henryVIII);