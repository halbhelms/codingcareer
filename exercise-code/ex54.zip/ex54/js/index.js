// create "answers" array with correct option ids
const answers = [
  'O1c', 'O2a', 'O3b', 'O4d', 'O5c', 'O6c', 'O7b', 'O8c', 'O9d', 'O10d', 'O11b', 'O12b'
]

// create "attempts" array to hold user guesses
const attempts = []

// create a "clearAttempts" helper function that will clear attempt class from all siblings
let clearAttempts = element => {
  let siblings = element.parentNode.children
  let siblingsArray = Array.prototype.slice.call(siblings)
  siblingsArray.forEach( sibling => {
    sibling.classList.remove('attempt')
  })
};

// create a "markAttempt" function to be used as an event for li elements
const markAttempt = event => {
  clearAttempts(event.target)
  event.target.classList.add('attempt')
}

// add an event listener to all the answers
const options = document.querySelectorAll('li')
const optionsArray = Array.prototype.slice.call(options)
optionsArray.forEach( option => {
  option.addEventListener('click', markAttempt)
})

// create a "scoreAttempts" function
const scoreAttempts = () => {
  const correctAttempts = document.querySelectorAll('.attempt.correct').length
  document.querySelector('#score').innerHTML = `You got ${(correctAttempts/answers.length * 100).toFixed(2)}% correct`
}


// create a "markCorrectAnswers" to be used as an event listener for button element
const markCorrectAnswers = () => {
  answers.forEach( answer => {
    document.getElementById(answer).classList.add('correct')
  })
  scoreAttempts()
}

document.querySelector('button').addEventListener('click', markCorrectAnswers)