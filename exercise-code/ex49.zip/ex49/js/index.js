let getRandomAnswer = (max) => {
  return Math.floor(Math.random() * Math.floor(max))
}

let answer = () => {
  document.querySelector('#answer').src = `../images/${getRandomAnswer(8)}.png`
}

document.querySelector('button').addEventListener('click', answer)