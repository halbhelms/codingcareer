// create object of bee hive parts and info
const beehive = {
  roof: {
    title: 'Roof',
    info: 'The roof of your beehive takes the brunt of abuse from sun, rain, snow, and other climatic challenges. The roof (or outer cover) is a critical component for keeping your hive dry and your bees safe from the elements. Suitable roofing materials include aluminum flashing, asphalt roofing shingles, cedar shake shingles, copper flashing, roofing and felt paper.'
  },
  innerCover: {
    title: 'Inner Cover',
    info: 'One of the possibly most overlooked pieces of hive tech in a conventional bee hive is the inner cover.  This is the board that sits on the top-most box in the hive stack and is usually covered by a top cover called a “telescoping cover”. The inner cover acts as a lid or cover to the hive that has a “peek-hole” to spy on bees if need be.  Honey bees very often use propolis to seal cracks, crevices, small gaps and and even small holes inside the hive.  The crevice created by placing a lid over a bee hive counts as “seal-able” to the bees.  A telescoping top cover with sides that fit down around the box can seem nearly impossible to remove if the bees propolise the lid from the inside.  Getting a tool under it is not easy because of the edges that extend down and around the top-most box.'
  },
  honeySuper: {
    title: 'Honey Super',
    info: 'The honey super is a box that holds the frames where the bees will store their honey. The honey supers come in different sizes, usually medium or shallow. It is recommended to use a medium or shallow size super for honey, instead of a deep, because honey is very heavy and the supers can be hard to lift when full.  The medium super tends to be the size most baeekeepers choose.  You can stack as many honey supers on top of the hive as needed for the honey flow.'
  },
  queenExcluder: {
    title: 'Queen Excluder',
    info: 'The intent of the queen excluder is to limit the queen\'s access to the honey supers. If the queen lays eggs in the honey supers and a brood develops in them it is difficult to harvest clean honey. It makes fall management more difficult. Queen excluders are removed in the autumn; otherwise, the queen would not be able to move with the winter cluster and would die from exposure. A replacement queen can be difficult to introduce because the bees will not be accustomed to the new queen\'s pheromones. New queens can be killed by the hive. Therefore, the death of a queen in winter is dangerous for a hive and can be expensive for a beekeeper.'
  },
  broodChamber: {
    title: 'Brood Chamber',
    info: 'The brood chamber (usually in the bottom boxes of the hive) houses worker-made cells where the eggs, larvae and pupae develop. Some of the cells in this part of the hive also hold pollen, nectar or honey that\'s used to feed the developing larvae. Many beekeepers use a screen called a "queen excluder" to keep the queen in the hive\'s lower boxes. This stops her from laying eggs in the honey supers, or upper boxes, which hold the frames that the beekeeper removes to collect the honey.'
  },
  bottomBoard: {
    title: 'Bottom Board',
    info: 'A bottom board is the floor of the beehive. It consists of several rails that serve as a frame around a solid piece of wood, and it protects the colony from damp ground. These days, more and more beekeepers are using what’s called a screened bottom board in place of the standard bottom board. This improves ventilation and is helpful when controlling and monitoring the colony’s population of varroa mites.'
  },
  elevatedStand: {
    title: 'Elevated Stand',
    info: 'An elevated hive stand is exactly what it sounds like: an item you use to hold a beehive off the ground. Many beekeepers put all of their hives on this kind of stand.This stand is ideal for a Langstroth hive (eight or ten frame), a Warre hivé, or to hold a couple of five‐frame nuc hives. The generous top surface not only accommodates the hive, but there’s some extra surface area to place your smoker, tools, and the frames you remove for inspection.'
  }
}

const partDetails = event => {
  event.preventDefault()
  document.querySelector('#title').innerHTML = beehive[event.target.title].title
  document.querySelector('#details').innerHTML = beehive[event.target.title].info
}

const areas = document.querySelectorAll('area')
const areasArray = Array.prototype.slice.call(areas)
areasArray.forEach(area => {
  area.addEventListener('click', partDetails)
})