const submitForm = (event) =>{
  event.preventDefault()
} 

document.querySelector('#theForm').addEventListener('submit', submitForm)

let checkCC = () => {
  let el = document.getElementById('cardNumber');
  let isValid = validCreditCard(el.value);
  console.log(isValid)
  if (isValid) {
    el.setCustomValidity('')
  } else {
    el.setCustomValidity('This is not a valid cc')
  }
}

document.getElementById('cardNumber').addEventListener('change', checkCC)

