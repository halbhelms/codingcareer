// create a "cells" object to mimic tic-tac-toe board
let cells = {
  a1: null,
  a2: null,
  a3: null,
  b1: null,
  b2: null,
  b3: null,
  c1: null,
  c2: null,
  c3: null,
}

// create "nextPlayer" variable for who the next player will be
let nextPlayer = 'x'

// create a "togglePlayer" function to switch out nextPlayer
let togglePlayer = () => {
  if (nextPlayer === 'x') {
    nextPlayer = 'o'
  } else {
    nextPlayer = 'x'
  }
}

// create a function, "processClick" to be called when a player clicks a cell
let processClick = event => {
  // add the class for the next player (which is now current player)
  event.target.classList.add(nextPlayer)
  // remove the click event listener since we don't want to respond to a cell that's been clicked on
  event.target.removeEventListener('click', processClick)
  // find the cell id of the cell clicked on
  let cellId = event.target.id
  // in the cell object, register the next player value (which is now current player) with the key (where key is the cell id)
  cells[cellId] = nextPlayer
  // change next player by calling togglePlayer
  togglePlayer()
  // check to see if we have a winner
  checkForWinner(tracks)
}

// create a "display" function to add the event listener to each cell
let display = () => {
  Object.keys(cells).forEach(cell => {
    let element = document.getElementById(cell)
    element.addEventListener('click', processClick)
  })
}

// create a 2d array of all possible way to win: horizontal, vertical, and diagonal
let tracks = [
  ['a1', 'b1', 'c1'],
  ['a2', 'b2', 'c2'],
  ['a3', 'b3', 'c3'],
  ['a1', 'a2', 'a3'],
  ['b1', 'b2', 'b3'],
  ['c1', 'c2', 'c3'],
  ['a1', 'b2', 'c3'],
  ['c1', 'b2', 'a3'],
]

// create "printWinner" function that will announce winner of the game
let printWinner = player => {
  document.getElementById('winner').innerHTML = `Player ${cells[player]} wins!`
}

// create a "checkForWinner" function to check for the winner
let checkForWinner = tracks => {
  // loop over each of the tracks
  tracks.forEach(track => {
    // get the "cells" value for each of the tracks
    let trackValue = cells[track[0]] + cells[track[1]] + cells[track[2]]
    // if a given track has all x's or all o's we have a winner
    if (trackValue === "xxx" || trackValue === "ooo") {
      // if we have a winner, call printWinner function
      printWinner(track[0])
    }
  })  
}

// start things off by calling display function
display()