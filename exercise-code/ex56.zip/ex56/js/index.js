// create a "nextSection" function to be attached to the img elements
const nextSection = event => {
  document.querySelector(`#${event.target.dataset.next}`).classList.remove('hidden')
}

const imgs = document.querySelectorAll('img')
const imgsArray = Array.prototype.slice.call(imgs)
imgsArray.forEach( img => {
  img.addEventListener('click', nextSection)
})
