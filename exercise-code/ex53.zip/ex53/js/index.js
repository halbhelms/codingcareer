// attach an event listener to #linkNewBudgetCategory click to remove class "hidden" from #newBudgetCategory
document.querySelector('#linkNewBudgetCategory').addEventListener('click', event => {
   document.querySelector('#newBudgetCategory').classList.remove('hidden')
})

// attach an event listener to #linkNewExpense click to remove class "hidden" from #newExpense
document.querySelector('#linkNewExpense').addEventListener('click', event => {
   document.querySelector('#newExpense').classList.remove('hidden')
})

// create a "budgetCategories" object to store a budget category and the budget for that category
const budgetCategories = {
   ['Car']: 395,
   ['Housing']: 1850
}

// create a "addBudgetCategory" function that reads from the #categoryForm and adds the info into budgetCategories
const addBudgetCategory = () => {
   budgetCategories[document.querySelector('#categoryName').value] = parseFloat(document.querySelector('#budgetAmount').value)
   document.querySelector('#categoryName').value = ''
   document.querySelector('#budgetAmount').value = ''
   document.querySelector('#newBudgetCategory').classList.add('hidden')
   displayBudgetCategories()
}

// assign "addBudgetCategory" function to add to #btnAddBudgetCategory click event
document.querySelector('#btnAddBudgetCategory').addEventListener('click', addBudgetCategory)

// create an "expenses" array to store a description, amount, and budget category
const expenses = [{
      description: 'Monthly car payment',
      amount: 415,
      budgetCategory: 'Car'
   },
   {
      description: 'Gas fill-up',
      amount: 37.50,
      budgetCategory: 'Car'
   },
   {
      description: 'Mortgage payment',
      amount: 1250,
      budgetCategory: 'Housing'
   }
]

// create a "addExpense" function to add to #btnAddExpense click event
const addExpense = () => {
   let expense = {}
   expense.description = document.querySelector('#description').value
   expense.amount = parseFloat(document.querySelector('#amount').value)
   expense.budgetCategory = document.querySelector('#category').value
   expenses.push(expense)
   console.log(expense)
   document.querySelector('#description').value = ''
   document.querySelector('#amount').value = ''
   document.querySelector('#category').selectedIndex = false
   // hide #newExpense
   document.querySelector('#newExpense').classList.add('hidden')
   // refresh expenses and budget categories
   displayExpenses()
   displayBudgetCategories()
}

document.querySelector('#btnAddExpense').addEventListener('click', addExpense)

// create a "newExpense" function to add to #linkNewExpense click event
const newExpense = () => {
   document.querySelector('#newExpense').classList.remove('hidden')
   const selectCategory = document.querySelector('#category')
   selectCategory.innerHTML = ''
   // create first option as a blank option
   let blankOption = document.createElement('option')
   blankOption.innerHTML = ''
   blankOption.value = ''
   selectCategory.appendChild(blankOption)
   // create options for all budget categories
   Object.keys(budgetCategories).forEach(category => {
      let option = document.createElement('option')
      option.innerHTML = category
      option.value = category
      selectCategory.appendChild(option)
   })
}

document.querySelector('#linkNewExpense').addEventListener('click', newExpense)

// create a "categoryTotal" function that accepts a budget category and totals the expenses for that category
const categoryTotal = category => {
   let total = 0
   expenses.forEach(expense => {
      if (expense.budgetCategory === category) {
         total += expense.amount
      }
   })
   return total
}

// create a "moneyFormat" function that accepts a value and returns it formatted as money
const moneyFormat = amount => {
   return amount.toFixed(2)
}

// create a "budgetChart" function that accepts a budget amount, spent amount, and pixel width and returns a simple chart showing percent of budget used
const budgetChart = (budgetAmount, spentAmount, pixelWidth = 200) => {
   // outer div of chart
   let chart = document.createElement('div')
   let chartClass = document.createAttribute('class')
   chartClass.value = 'outer-budget-chart'
   chart.setAttributeNode(chartClass)
   // inner span of chart
   // calculate width based on pixelWidth outer chart div
   let calculatedWidth = (pixelWidth / budgetAmount) * spentAmount
   let color = 'blue'
   if (calculatedWidth > pixelWidth) {
      color = 'red'
   }
   if (calculatedWidth > pixelWidth) {
      calculatedWidth = pixelWidth
   }
   let span = document.createElement('span')

   span.style.cssText = `width: ${calculatedWidth}; background-color: ${color}`

   let spanClass = document.createAttribute('class')
   spanClass.value = 'inner-budget-chart'
   span.setAttributeNode(spanClass)
   chart.appendChild(span)
   return chart
}

// on page load, display the current budget categories and the expenses
const displayBudgetCategories = () => {
   const budgetCategoriesEl = document.querySelector('#budgetCategories')
   budgetCategoriesEl.innerHTML = ''

   Object.keys(budgetCategories).forEach(key => {
      // text portion
      let p = document.createElement('p')
      let pClass = document.createAttribute('class')
      pClass.value = 'budget-category-text'
      p.setAttributeNode(pClass)
      p.innerHTML = `${key} : ${moneyFormat(categoryTotal(key))} of ${moneyFormat(budgetCategories[key])}`
      // wrapper for both text and chart
      let wrapper = document.createElement('div')
      let wrapperClass = document.createAttribute('class')
      wrapperClass.value = 'wrapper'
      wrapper.setAttributeNode(wrapperClass)
      wrapper.appendChild(p)
      wrapper.appendChild(budgetChart(budgetCategories[key], categoryTotal(key)))
      budgetCategoriesEl.appendChild(wrapper)
   })
}


displayBudgetCategories()

const displayExpenses = () => {
   const budgetExpensesEl = document.querySelector('#budgetExpenses')
   budgetExpensesEl.innerHTML = ''
   expenses.forEach(expense => {
      let p = document.createElement('p')
      p.innerHTML = `${expense.description} (${expense.budgetCategory}) ${moneyFormat(expense.amount)}`
      budgetExpensesEl.appendChild(p)
   })
}

// Fire things off
displayExpenses()