const selectContent = (event) => {
  const newContent = event.currentTarget.id;
  // console.log(newContent);
  fetch(`../html/${newContent}.html`)
  .then( data => data.text())
  .then( content => {
    console.log(content)
    document.getElementById('mainDisplay').innerHTML = content
  })
}

const navItems = document.querySelectorAll('.nav-item')
const navItemsArray = Array.prototype.slice.call(navItems)

navItems.forEach( navItem => {
  navItem.addEventListener('click', selectContent)
})